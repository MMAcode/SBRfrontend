// import React from 'react';
// import {useLoginSimple} from "./useLoginAs";
// export default function ForHookUseLoginAs({data: userData, setComponentNeeded: setThisComponentNeeded = false}) {
//     useLoginSimple(userData);
//     if (setThisComponentNeeded !=false) setThisComponentNeeded(false);
//     return null;
// }