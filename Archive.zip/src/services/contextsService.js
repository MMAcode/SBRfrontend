import React from "react";

export const userContextSource = React.createContext({});
export const quizContextSource = React.createContext({});
export const appContextSource = React.createContext({});
export const questionContextSource = React.createContext({});