//rsc
// import React from 'react';
//
// const C1 = () => {
//     return (
//         <div></div>
//     );
// };
//
// export default C1;


// rsf
import React from 'react';
export default function T(props) {
    return (
        <div>

        </div>
    );
}
