import React from 'react';
import QuizzesWrapper from "./quizzes/QuizzesWrapper";

export default function TestingQueries(props) {
    return (
        <div>
            <h1>Template:</h1>

        </div>
    );
}