### Online resources:
- best learning youtube playlist for react hooks: https://www.youtube.com/playlist?list=PLC3y8-rFHvwisvxhZ135pogtX7_Oe3Q3A

- Code resources for youtube playlist above: https://github.com/gopinav/React-Tutorials/tree/master/React%20Hooks

